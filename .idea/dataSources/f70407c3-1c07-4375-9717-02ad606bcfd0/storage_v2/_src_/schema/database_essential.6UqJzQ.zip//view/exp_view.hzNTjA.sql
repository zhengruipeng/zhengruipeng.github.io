create definer = root@localhost view exp_view as
select `database essential`.`student`.`id`      AS `id`,
       `database essential`.`student`.`sname`   AS `sname`,
       `database essential`.`student`.`sage`    AS `sage`,
       `sc`.`grade`                             AS `grade`,
       `database essential`.`course`.`course`   AS `course`,
       `database essential`.`course`.`courseId` AS `courseId`,
       `database essential`.`course`.`period`   AS `period`
from `database essential`.`student`
         join `database essential`.`studentgrade` `sc`
         join `database essential`.`course`
where `database essential`.`student`.`id` = `sc`.`sId`
  and `database essential`.`course`.`courseId` = `sc`.`cId`;

