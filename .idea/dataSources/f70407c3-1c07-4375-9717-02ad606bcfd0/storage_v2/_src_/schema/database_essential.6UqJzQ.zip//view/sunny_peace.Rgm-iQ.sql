create definer = root@localhost view sunny_peace as
select `database essential`.`student`.`id`    AS `学号`,
       `database essential`.`student`.`sname` AS `姓名`,
       `database essential`.`student`.`sdept` AS `组合`,
       `database essential`.`student`.`sage`  AS `年龄`
from `database essential`.`student`
where `database essential`.`student`.`sdept` = 'sunny peace';

