create definer = root@localhost view v_1 as
select distinct `database essential`.`student`.`id`    AS `id`,
                `database essential`.`student`.`sname` AS `sname`,
                `database essential`.`student`.`sage`  AS `sage`,
                `database essential`.`student`.`sdept` AS `sdept`
from `database essential`.`student`
         join `database essential`.`studentgrade`
where `database essential`.`student`.`sage` > 15
  and `database essential`.`student`.`id` = `database essential`.`studentgrade`.`sId`;

