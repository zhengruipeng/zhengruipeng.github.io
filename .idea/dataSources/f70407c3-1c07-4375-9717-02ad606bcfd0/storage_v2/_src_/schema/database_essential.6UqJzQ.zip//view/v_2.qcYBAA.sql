create definer = root@localhost view v_2 as
select `v_1`.`id`                                  AS `学号`,
       `v_1`.`sname`                               AS `姓名`,
       `database essential`.`studentgrade`.`cId`   AS `课程id`,
       `database essential`.`studentgrade`.`grade` AS `成绩`
from `database essential`.`v_1`
         join `database essential`.`studentgrade`
where `v_1`.`id` = `database essential`.`studentgrade`.`sId`;

