# Step-by-Step WebGPU Graphics Programming (1) 
## Set Up Development Environment for WebGPU App

This is the source code for the first part of a series YouTube videos on step-by-step WebGPU graphics programming.

The develpment tools used in our WebGPU sample apps include: 

* Visual Studio Code (VSCode) as IDE.
* Node.js and npm as the package management.
* TypeScript as the language for developing front-end apps. 
* WebPack as the module bundler.
* Chrome Canary as the browser for viewing WebGPU apps.

## Link for All Source Code Used in the WebGPU Step-By-Step Video Series:

https://github.com/jack1232/WebGPU-Step-By-Step

