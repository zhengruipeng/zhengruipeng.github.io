import $ from 'jquery';
import { CheckWebGPU } from './helper';

$('#id-gpu-check').html(CheckWebGPU());

