# Step-by-Step WebGPU Graphics Programming (2) 
## Create First Triangle with the WebGPU API

This is the source code for the second part of a series YouTube videos on step-by-step WebGPU graphics programming.

This sample WebGPU app creates a triangle whose color can be specifed by the user. The output from the app is shown in the following image.

![wg02-01](dist/assets/wg02-01.png)

## Link for All Source Code Used in the WebGPU Step-By-Step Video Series:

https://github.com/jack1232/WebGPU-Step-By-Step

