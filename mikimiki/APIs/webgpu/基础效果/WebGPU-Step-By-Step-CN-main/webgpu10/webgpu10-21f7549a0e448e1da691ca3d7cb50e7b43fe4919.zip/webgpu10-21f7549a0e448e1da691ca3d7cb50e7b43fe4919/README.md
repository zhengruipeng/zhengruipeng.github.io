# Step-by-Step WebGPU Graphics Programming (10) 
## Create Cube with Distinct Face Color 

This is the source code for the 10th part of a series YouTube videos on step-by-step WebGPU graphics programming.

This sample WebGPU app creates a cube with distinct face colors. The output from the app is shown in the following image.

![image02](dist/assets/image02.png)

## Link for All Source Code Used in the WebGPU Step-By-Step Video Series:

https://github.com/jack1232/WebGPU-Step-By-Step