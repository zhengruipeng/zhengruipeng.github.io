# Step-by-Step WebGPU Graphics Programming (12) 
## Cube with Distinct Vertex Color

This is the source code for the 12th part of a series YouTube videos on step-by-step WebGPU graphics programming.

This sample WebGPU app creates a cube with distinct vertex color. The output from the app is shown in the following image.

![image01](dist/assets/image01.png)

## Link for All Source Code Used in the WebGPU Step-By-Step Video Series:

https://github.com/jack1232/WebGPU-Step-By-Step