<template>
	<views>
		news
	</views>
</template>

<script>
</script>

<style>
</style>
