<template>
	<view>
		shop
	</view>
</template>

<script>
</script>

<style>
</style>
